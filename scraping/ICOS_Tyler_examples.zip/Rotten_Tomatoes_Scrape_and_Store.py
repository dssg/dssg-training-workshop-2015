#rotten_test.py
from bs4 import BeautifulSoup
import urllib2
from bypass_function import *
import sqlite3 as lite
import sys

#################################


###############################
#	   Scraping functions		#
###############################

def Get_list_name(soup):
	for link in soup.find_all('h1'):
		name = link.text

	return name

# see the slideshow for a greater explanation
def Get_tomato_meter_rating(soup):
	temp_rating_list = []
	# look at all tables on the page
	for table in soup.find_all('table'):
		# from the list of all tables, find the 1 table where 'class' == 'left rt_table'
		if table.get('class')[0] == "left" and table.get('class')[1] == "rt_table":
			# find all table cells within this one table
			for td in table.find_all('td'):
				# find all links within table cells
				for link in td.find_all('span'):
					# find the one link inside of the span we want
					if link.get('class') and link.get('class')[0] == "tMeterScore":
						# get the value as a string
						rating = link.text
						try:
							# remove the last character.
							# the last char is % sign.
							rating = rating[:-1]
						except:
							print "I couldn't remove the percent sign!"
	
						temp_rating_list.append(rating)

	return temp_rating_list

def Get_titles(soup):
	temp_title_list = []
	# look at all tables
	for table in soup.find_all('table'):
		# find main table with info
		if table.get('class')[0] == "left" and table.get('class')[1] == "rt_table":
			# find anchor tag we are looking for
			for link in table.find_all('a'):
				# grab title as string
				temp_title = link.text
				# add to list of all titles
				temp_title_list.append(temp_title)

	return temp_title_list

def Get_url(soup):
	temp_url_list = []
	for table in soup.find_all('table'):
		if table.get('class')[0] == "left" and table.get('class')[1] == "rt_table":
			for link in table.find_all('a'):
				temp_url = link.get('href')
				temp_url_list.append(temp_url)

	return temp_url_list


#################################
#		Table functions 	#
#################################

def Drop_table(cur, table_name):
	drop_string = "DROP TABLE IF EXISTS \"%s\"" % table_name
	#print drop_string
	cur.execute(drop_string)

def Add_table(cur, table_name):
	add_string = "CREATE TABLE \"%s\"(name TEXT, rating INT, link TEXT)" % table_name
	#print add_string
	cur.execute(add_string)

def Insert_into_table(cur, table_name, list_of_movies):
	insert_string = "INSERT INTO \"%s\" VALUES(?, ?, ?)" % table_name
	#print insert_string
	cur.executemany(insert_string, list_of_movies)



#################################
#		Start Main Code	#
#################################

BASE_URL = "http://www.rottentomatoes.com/top/bestofrt/?category="
list_of_lists = []
list_of_list_names = []
MOVIES_PER_PAGE = 100

list_of_pages = [1,2,4,5]

# visit every individual web page
for i in list_of_pages:

	temp_list = []

	# Setup objects & retrieve web page
	url = BASE_URL + str(i)
	print url
	content = Get_website_text(url)
	soup = BeautifulSoup(content)


	#########################
	# 	start populating list 	#		
	#########################

	temp_list_name = Get_list_name(soup)

	# add this to our list of names
	list_of_list_names.append(temp_list_name)
	#print temp_list_name

	temp_ratings = Get_tomato_meter_rating(soup)
	#print temp_ratings

	temp_titles = Get_titles(soup)
	#print temp_titles

	temp_urls = Get_url(soup)
	#print temp_urls

	for i in range(0, MOVIES_PER_PAGE):

		temp_tuple = (temp_titles[i], float(temp_ratings[i]), temp_urls[i])
		temp_list.append(temp_tuple)
		#print temp_tuple

	list_of_lists.append(temp_list)


###############################
# 	Push our lists into tables 	#
###############################

con = lite.connect('test.sqlite')
cur = con.cursor()

with con:
	i = 0
	for single_list in list_of_lists:

		# Create Table with name of Genre
		Drop_table(cur, list_of_list_names[i])
		Add_table(cur, list_of_list_names[i])

		# add our tuples in
		Insert_into_table(cur, list_of_list_names[i], single_list)

		# look at what we are adding
		#for film in single_list:
		#	print film[2]

		i += 1




