#################################
#		Documentation			#
#################################

# Python & Sqlite3 tutorial

# UM-IBUG Big Data camp
# Written By: Tyler Markvluwer
# Email: tylermar@umich.edu
# Date: 2014/5/22

# examples inspired(aka. stolen from) by http://zetcode.com/db/sqlitepythontutorial/

# This file shows how to create tuples, sets, and
# import them into databases, and take them out of
# databases.

#################################
#			 Code				#
#################################

import sqlite3 as lite	# needed to use sqlite
import sys				# may not be needed...

# create a set of "cars".
# each item in the set is a "tuple" similar to 
# those found in databases
cars_variable = (
	(1, 'Audi', 52642),
	(2, 'Mercedes', 57127),
	(3, 'Skoda', 9000),
	(4, 'Volvo', 29000),
	(5, 'Bentley', 350000),
	(6, 'Hummer', 41400),
	(7, 'Volkswagen', 21600)
)

# We need to connect or create a database
# to hold our tables in.
con = lite.connect('test.sqlite')	# if "test.db" does not exist, it will be created

with con:

	# create a cursor, that is able to move through 
	# the tables in the database
	cur = con.cursor()

	# drop the table if it already exists
	cur.execute("DROP TABLE IF EXISTS Cars")

	# add our new table
	cur.execute("CREATE TABLE Cars(Id INT, Name TEXT, Price INT)")

	# add all of our tuples from the cars_variable
	# into the database at once. This only works if our variable
	# is a set of tuples.
	cur.executemany("INSERT INTO Cars VALUES(?, ?, ?)", cars_variable)

	# alternative option, to add each one individually
	# this line currently inserts the 1st tuple
	cur.execute("INSERT INTO CARS VALUES(?, ?, ?)", cars_variable[0])

	# This will allow us to use our info
	cur.execute("SELECT * FROM Cars")
	rows = cur.fetchall()


	#################################
	#			Print/Check			#
	#################################

	# print our rows to see what is in our database
	row_num = 1
	for row in rows:
		print row_num
		row_num += 1
		print row

# the 'with' keyword will close our db

# We are finished! That wasn't too bad!