import urllib2
import cookielib


# returns the text of websites which block python scripts
# e.g.
#
# my_text = Get_website_text("http://www.beeradvocate.com")
#
#
def Get_website_text(url):

	# url for website        
	base_url = url
	     
	# file for storing cookies       
	cookie_file = 'mfp.cookies'
	 
	# set up a cookie jar to store cookies
	cj = cookielib.MozillaCookieJar(cookie_file)
	 
	# set up opener to handle cookies, redirects etc
	opener = urllib2.build_opener(
	     urllib2.HTTPRedirectHandler(),
	     urllib2.HTTPHandler(debuglevel=0),
	     urllib2.HTTPSHandler(debuglevel=0),            
	     urllib2.HTTPCookieProcessor(cj)
	)

	# pretend we're a web browser and not a python script
	opener.addheaders = [('User-agent',
	    ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) '
	     'AppleWebKit/535.1 (KHTML, like Gecko) '
	     'Chrome/13.0.782.13 Safari/535.1'))
	]

	# open the front page of the website to set
	# and save initial cookies
	response = opener.open(base_url)
	web_text = response.read()
	response.close()

	return web_text