import twitter
import oauthDance
import time

#########  Get all tweets from the authenticated user


def printTexts(tweets) :
    oldest = None
    count = 0
    for tweet in tweets :
        count = count + 1
        print tweet['text']
        if (oldest is None or tweet['id'] < oldest) :
            oldest = tweet['id']
    print count        
    return (oldest, count)

t = oauthDance.login()

### what is the current user?
settings = t.account.settings()
user = settings['screen_name'];

# Get tweets until done, max is 200 at a time

# First, get the "newest" tweet ID.  That is where we will start
newest = t.statuses.user_timeline(screen_name=user,count=1)
nextID = newest[0]['id']

total = 0
count = 0

while True :
    tweets = t.statuses.user_timeline(screen_name=user, 
                                      count=200,
                                      max_id = nextID)
    nextID, count = printTexts(tweets)
    if (nextID is None) :
        break
    nextID = nextID - 1
    total = total + count
    time.sleep(2)
    
print total



