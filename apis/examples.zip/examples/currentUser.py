import twitter
import oauthDance

#########  Get four tweets of authenticated user, in two calls

def printTexts(tweets) :
    oldest = None
    for tweet in tweets :
        print tweet['text']
        if (oldest is None or tweet['id'] < oldest) :
            oldest = tweet['id']
    return oldest

t = oauthDance.login()

### what is the current user?
settings = t.account.settings()
user = settings['screen_name'];

# Get the first two
firstTweets = t.statuses.user_timeline(screen_name=user, count=2)

# Compute the largest possible ID for the "next youngest" tweet
nextID =  printTexts(firstTweets) - 1

nextTweets = t.statuses.user_timeline(screen_name=user, 
                                      count = 2, max_id = nextID)

printTexts(nextTweets)






