import twitter
import oauthDance
import json

t = oauthDance.login()

# Streaming is a different interface
ts = twitter.TwitterStream(auth=t.auth)

# Oh My!
iterator = ts.statuses.filter(track="Lions,Tigers,Bears")

for tweet in iterator :
    print tweet['text']
