import twitter
import oauthDance
import json

###### an example of a search query based on location.

t = oauthDance.login()

print
print
print "Current Los Angeles hockey mentions"
result = t.search.tweets(q="hockey place:3b77caf94bfc81fe")
for tweet in result['statuses'] :
    print tweet['user']['screen_name'] + '       ' + tweet['text']
    print


print
print
print "Current Chicago hockey mentions"
result = t.search.tweets(q="hockey place:1d9a5370a355ab0c")
for tweet in result['statuses'] :
    print tweet['user']['screen_name'] + '       ' + tweet['text']
    print 

