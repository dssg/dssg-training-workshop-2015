import twitter
import oauthDance
import json

###### an example of a search query with time limits

t = oauthDance.login()

print "Detroit Tigers mentions before May 15"
result = t.search.tweets(q="Detroit Tigers until:2014-05-15")
for tweet in result['statuses'] :
    print tweet['user']['screen_name'] + '       ' + tweet['text']
    print


print
print
print "Current Detroit Tigers mentions"
result = t.search.tweets(q="Detroit Tigers")
for tweet in result['statuses'] :
    # print tweet['screen_name'] + '       ' + tweet['text']
    # print json.dumps(tweet, indent=4)
    print tweet['user']['screen_name'] + '       ' + tweet['text']
    print


print
print
print "Brian talks about tweets a lot"
result = t.search.tweets(q="from:bdnoble tweet")
for tweet in result['statuses'] :
    print tweet['user']['screen_name'] + '       ' + tweet['text']
    print 

