import twitter
import oauthDance

t = oauthDance.login()

print "Success!"








