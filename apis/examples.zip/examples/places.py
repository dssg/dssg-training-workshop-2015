import twitter
import oauthDance
import json

t = oauthDance.login()

losangeles = t.geo.search(query="Los Angeles", granularity="city")
chicago = t.geo.search(query="Chicago", granularity="city")
annarbor = t.geo.search(query="Ann Arbor", granularity="city")


for place in losangeles['result']['places'] :
    print place['id'] + '    ' + place['full_name']

print
print
print
for place in chicago['result']['places'] : 
    print place['id'] + '      ' + place['full_name']


print
print
print
for place in annarbor['result']['places'] :
    print place['id'] + '    ' + place['full_name']
    print json.dumps(place,indent=4)
